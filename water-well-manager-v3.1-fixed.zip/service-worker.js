// Service worker intentionally disabled in v3.1 to prevent stale cached builds.
self.addEventListener("install", event => self.skipWaiting())
self.addEventListener("activate", event => event.waitUntil(self.clients.claim()))
