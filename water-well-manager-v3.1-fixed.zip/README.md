
# Municipal Water Well Manager v3

Advanced open-source tool for municipal water departments.

## Features

• Runtime tracking  
• Meter production tracking  
• Efficiency analytics (gal/hr)  
• Production charts  
• Monthly CSV reports  
• Backup / restore system  
• Offline PWA support  

## Deploy

Upload repository to GitHub and enable GitHub Pages.

## Stack

HTML  
CSS  
Vanilla JavaScript  
Chart.js
